import { type User, type InsertUser, type Contact, type InsertContact, type Experience, type InsertExperience, type Skill, type InsertSkill, type Project, type InsertProject } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  
  // Experience methods
  getExperiences(): Promise<Experience[]>;
  createExperience(experience: InsertExperience): Promise<Experience>;
  
  // Skills methods
  getSkills(): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  
  // Projects methods
  getProjects(): Promise<Project[]>;
  getFeaturedProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private contacts: Map<string, Contact>;
  private experiences: Map<string, Experience>;
  private skills: Map<string, Skill>;
  private projects: Map<string, Project>;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.experiences = new Map();
    this.skills = new Map();
    this.projects = new Map();
    
    // Initialize with portfolio data
    this.initializeData();
  }

  private initializeData() {
    // Initialize experiences
    const experienceData: Omit<Experience, 'id'>[] = [
      {
        title: "Chief Executive Officer",
        company: "Albader Inc",
        location: "Lahore, Punjab, Pakistan",
        startDate: "2022",
        endDate: null,
        description: "Leading enterprise sales transformation initiatives across technology, finance, and telecommunications. Generated $20M+ in new business pipeline through strategic B2B partnerships. Implemented AI-powered sales automation systems resulting in 300% revenue increase. Led cross-functional teams to close deals averaging $500K+ with Fortune 500 clients including enterprise SaaS, cloud infrastructure, and digital transformation projects.",
        type: "full-time",
        order: 1
      },
      {
        title: "Manager of Sales",
        company: "Imperial Resource Group",
        location: "Lahore, Punjab, Pakistan",
        startDate: "Apr 2025",
        endDate: "Aug 2025",
        description: "Promoted to Sales Manager for exceptional performance in enterprise B2B sales. Generated $15M+ in qualified pipeline through strategic outbound campaigns targeting Fortune 1000 prospects. Achieved 156% of quota while managing 50+ enterprise accounts. Led digital marketing automation initiatives that reduced sales cycle by 40% and increased conversion rates by 85%. Specialized in SaaS solutions for financial services and telecommunications sectors.",
        type: "full-time",
        order: 2
      },
      {
        title: "Software Developer",
        company: "Imperial Resource Group",
        location: "Lahore, Punjab, Pakistan",
        startDate: "Mar 2024",
        endDate: "Aug 2025",
        description: "As a Full-Stack Software Developer, I design and develop dynamic, user-friendly interfaces using HTML, CSS, and JavaScript frameworks like React or Vue.js. On the backend, I build scalable, high-performance applications with PHP, Python, or Node.js, integrating databases like MySQL, PostgreSQL, or MongoDB. I develop and connect RESTful and GraphQL APIs while implementing security best practices, authentication, and data protection. With expertise in AI integration, I leverage machine learning models, automation, and predictive analytics to enhance software functionality.",
        type: "internship",
        order: 3
      },
      {
        title: "Senior Sales Executive",
        company: "Imperial Resource Group",
        location: "Lahore, Punjab, Pakistan",
        startDate: "Sep 2022",
        endDate: "Aug 2025",
        description: "Consistently ranked top 5% performer, closing $12M+ in new business across technology and financial services sectors. Managed enterprise accounts with average deal sizes of $250K+. Developed and executed strategic account plans for 75+ Fortune 500 prospects, achieving 180% of annual quota. Specialized in complex B2B sales cycles including multi-stakeholder negotiations, technical demonstrations, and C-level presentations. Led cross-selling initiatives that increased account value by 220%.",
        type: "full-time",
        order: 4
      },
      {
        title: "Senior Sales Executive", 
        company: "IRG Global Technologies",
        location: "Lahore, Punjab, Pakistan",
        startDate: "Aug 2022",
        endDate: "Aug 2025",
        description: "Led enterprise technology sales generating $8M+ in annual revenue across cloud infrastructure, cybersecurity, and AI solutions. Managed strategic partnerships with technology vendors and system integrators. Closed deals with average value of $180K+ through consultative selling and technical solution design. Developed go-to-market strategies for new product launches resulting in 145% of territory goals. Expertise in Salesforce, HubSpot, and enterprise sales methodologies.",
        type: "full-time",
        order: 5
      },
      {
        title: "Senior Sales Account Executive",
        company: "Tranche Technologies", 
        location: "Lahore, Punjab, Pakistan",
        startDate: "Jan 2021",
        endDate: "Dec 2021",
        description: "Managed 25+ enterprise accounts with combined portfolio value of $5M+. Achieved 165% of annual quota through strategic account management and consultative selling. Led contract negotiations for complex technology implementations averaging $120K+ per deal. Developed and executed territory expansion strategies resulting in 200% growth in new logo acquisition. Specialized in financial technology and telecommunications solutions.",
        type: "full-time",
        order: 6
      }
    ];

    experienceData.forEach(exp => {
      const id = randomUUID();
      this.experiences.set(id, { 
        ...exp, 
        id,
        order: exp.order ?? 0,
        endDate: exp.endDate ?? null
      });
    });

    // Initialize skills
    const skillsData: Omit<Skill, 'id'>[] = [
      { name: "Enterprise B2B Sales Strategy", category: "sales", percentage: 98, icon: "fas fa-chart-line" },
      { name: "Salesforce & HubSpot CRM", category: "sales", percentage: 95, icon: "fas fa-database" },
      { name: "Complex Deal Negotiation", category: "sales", percentage: 96, icon: "fas fa-handshake" },
      { name: "C-Level Executive Selling", category: "sales", percentage: 94, icon: "fas fa-users-crown" },
      { name: "Digital Marketing Automation", category: "marketing", percentage: 92, icon: "fas fa-bullhorn" },
      { name: "Lead Generation & Prospecting", category: "marketing", percentage: 89, icon: "fas fa-search" },
      { name: "Financial Services Sales", category: "industry", percentage: 91, icon: "fas fa-university" },
      { name: "Technology & SaaS Solutions", category: "industry", percentage: 93, icon: "fas fa-laptop-code" },
      { name: "Telecommunications & Cloud", category: "industry", percentage: 88, icon: "fas fa-network-wired" },
      { name: "Pipeline Management & Forecasting", category: "operations", percentage: 95, icon: "fas fa-chart-area" },
      { name: "Team Leadership & Coaching", category: "leadership", percentage: 94, icon: "fas fa-user-friends" },
      { name: "Cross-Industry Expertise", category: "leadership", percentage: 97, icon: "fas fa-globe" }
    ];

    skillsData.forEach(skill => {
      const id = randomUUID();
      this.skills.set(id, { 
        ...skill, 
        id,
        icon: skill.icon ?? null
      });
    });

    // Initialize projects
    const projectsData: Omit<Project, 'id'>[] = [
      {
        title: "AI-Powered CRM Platform",
        description: "Revolutionary customer relationship management system with AI-driven insights, automated lead scoring, and predictive analytics.",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
        technologies: ["React", "AI/ML", "Node.js", "PostgreSQL"],
        projectUrl: "#",
        githubUrl: "#",
        category: "AI & Machine Learning",
        featured: 1
      },
      {
        title: "Cloud Gaming Platform",
        description: "Scalable cloud-based gaming infrastructure with real-time multiplayer capabilities, cross-platform compatibility, and advanced graphics optimization.",
        imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
        technologies: ["Unity", "AWS", "WebRTC", "C#"],
        projectUrl: "#",
        githubUrl: "#",
        category: "Game Development",
        featured: 1
      },
      {
        title: "Business Automation Suite",
        description: "Comprehensive automation platform for streamlining business processes, reducing manual tasks, and optimizing workflow efficiency.",
        imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
        technologies: ["Python", "APIs", "RPA", "Docker"],
        projectUrl: "#",
        githubUrl: "#",
        category: "Business Automation",
        featured: 1
      },
      {
        title: "Next-Gen E-commerce",
        description: "Modern e-commerce platform with AI recommendations, seamless payments, and integrated inventory management system.",
        imageUrl: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
        technologies: ["Next.js", "Stripe", "MongoDB", "Redis"],
        projectUrl: "#",
        githubUrl: "#",
        category: "E-commerce",
        featured: 1
      },
      {
        title: "Real-time Analytics Dashboard",
        description: "Advanced analytics dashboard providing real-time insights, custom reporting, and predictive business intelligence.",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
        technologies: ["D3.js", "React", "GraphQL", "Python"],
        projectUrl: "#",
        githubUrl: "#",
        category: "Data Analytics",
        featured: 1
      },
      {
        title: "Cross-Platform Mobile App",
        description: "Feature-rich mobile application with offline capabilities, push notifications, and seamless synchronization across devices.",
        imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
        technologies: ["React Native", "Firebase", "Redux", "TypeScript"],
        projectUrl: "#",
        githubUrl: "#",
        category: "Mobile Development",
        featured: 1
      }
    ];

    projectsData.forEach(project => {
      const id = randomUUID();
      this.projects.set(id, { 
        ...project, 
        id,
        imageUrl: project.imageUrl ?? null,
        technologies: project.technologies ?? null,
        projectUrl: project.projectUrl ?? null,
        githubUrl: project.githubUrl ?? null,
        featured: project.featured ?? null
      });
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: new Date() 
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getExperiences(): Promise<Experience[]> {
    return Array.from(this.experiences.values()).sort((a, b) => a.order - b.order);
  }

  async createExperience(insertExperience: InsertExperience): Promise<Experience> {
    const id = randomUUID();
    const experience: Experience = { ...insertExperience, id };
    this.experiences.set(id, experience);
    return experience;
  }

  async getSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = randomUUID();
    const skill: Skill = { ...insertSkill, id };
    this.skills.set(id, skill);
    return skill;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getFeaturedProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.featured === 1);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = { ...insertProject, id };
    this.projects.set(id, project);
    return project;
  }
}

export const storage = new MemStorage();
